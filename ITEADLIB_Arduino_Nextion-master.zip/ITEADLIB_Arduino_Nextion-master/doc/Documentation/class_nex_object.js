var class_nex_object =
[
    [ "NexObject", "class_nex_object.html#ab15aadb9c91d9690786d8d25d12d94e1", null ],
    [ "printObjInfo", "class_nex_object.html#abeff0c61474e8b3ce6bac76771820b64", null ]
];